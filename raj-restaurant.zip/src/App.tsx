/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, X, MapPin, Phone, Clock, Instagram, 
  MessageCircle, Star, ChevronRight, ChefHat, 
  UtensilsCrossed 
} from 'lucide-react';

const navLinks = [
  { name: 'Home', href: '#home' },
  { name: 'Menu', href: '#menu' },
  { name: 'About', href: '#about' },
  { name: 'Gallery', href: '#gallery' },
  { name: 'Reviews', href: '#reviews' },
  { name: 'Contact', href: '#contact' },
];

const menuItems = [
  {
    name: 'Veg Momos',
    price: '₹20',
    desc: 'Steamed delicate dumplings filled with fresh vegetables and secret spices.',
    image: 'https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
  },
  {
    name: 'Fried Rice',
    price: '₹20',
    desc: 'Wok-tossed long-grain rice with seasonal greens and aromatic soy sauce.',
    image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
  },
  {
    name: 'Finger Snacks',
    price: '₹20',
    desc: 'Crispy, golden-fried assorted snacks, perfect for a quick bite.',
    image: 'https://images.unsplash.com/photo-1562967914-01efa7e87832?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
  },
  {
    name: 'Special Combo',
    price: '₹99',
    desc: 'The ultimate royal feast: Momos, Fried Rice, Snacks & Beverage.',
    image: 'https://images.unsplash.com/photo-1615719417325-103138b1f79a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
  }
];

const reviews = [
  {
    name: 'Aman Verma',
    rating: 5,
    text: 'Best momos in Sangipur! The quality you get for ₹20 is just unbelievable. Highly recommended.'
  },
  {
    name: 'Priya Singh',
    rating: 5,
    text: 'Loved the ambiance and the fast service. Their special combo is a must-try for everyone!'
  },
  {
    name: 'Rahul Yadav',
    rating: 5,
    text: 'Very hygienic and premium feel. Doesn\'t feel like a regular fast food joint. Great work Raj Restaurant!'
  }
];

const galleryImages = [
  'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1600891964092-4316c288032e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1514933651103-005eec06c04b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
];

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const fadeInUp = {
    initial: { opacity: 0, y: 40 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, margin: "-100px" },
    transition: { duration: 0.6, ease: "easeOut" }
  };

  const staggerContainer = {
    initial: { opacity: 0 },
    whileInView: { opacity: 1 },
    viewport: { once: true, margin: "-100px" },
    transition: { staggerChildren: 0.2 }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-neutral-200 font-sans selection:bg-orange-500/30 selection:text-orange-200">
      
      {/* Navbar */}
      <header 
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 border-b border-transparent ${
          isScrolled ? 'bg-black/80 backdrop-blur-md border-white/5 py-4' : 'bg-transparent py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <a href="#home" className="flex items-center gap-2 group">
            <ChefHat className="text-orange-500 w-8 h-8 group-hover:rotate-12 transition-transform duration-300" />
            <span className="font-serif text-2xl font-bold tracking-wide text-white glow-text">Raj Restaurant</span>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                className="text-sm font-medium text-neutral-300 hover:text-orange-400 transition-colors uppercase tracking-widest"
              >
                {link.name}
              </a>
            ))}
            <a 
              href="https://wa.me/917571827445" 
              target="_blank" rel="noreferrer"
              className="px-5 py-2 bg-gradient-to-r from-orange-600 to-red-600 rounded-full font-medium text-white glow-btn flex items-center gap-2"
            >
              Order Now
            </a>
          </nav>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden text-neutral-200 p-2"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </header>

      {/* Mobile Nav Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[60] bg-[#0a0a0a] flex flex-col p-6"
          >
            <div className="flex justify-between items-center mb-12">
              <span className="font-serif text-2xl font-bold text-white">Menu</span>
              <button onClick={() => setMobileMenuOpen(false)} aria-label="Close menu" className="p-2 border border-white/10 rounded-full text-neutral-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="flex flex-col gap-6 items-start">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-3xl font-serif text-neutral-400 hover:text-orange-500 transition-colors"
                >
                  {link.name}
                </a>
              ))}
              <div className="mt-8 w-full h-[1px] bg-white/10" />
              <a 
                href="https://wa.me/917571827445" 
                target="_blank" rel="noreferrer"
                className="mt-6 w-full py-4 text-center bg-orange-600 rounded-lg font-medium text-white glow-btn text-lg"
              >
                Order Online via WhatsApp
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80" 
            alt="Restaurant Background" 
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-[#050505]/80 to-[#050505]"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <span className="inline-block py-1 px-3 mb-6 border border-orange-500/30 rounded-full text-orange-400 text-sm font-medium tracking-widest uppercase bg-orange-500/10">
              Welcome to Sangipur's Finest
            </span>
            <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 leading-tight drop-shadow-2xl">
              Premium Taste at <br className="hidden md:block"/> 
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-300">
                Affordable Price
              </span>
            </h1>
            <p className="max-w-2xl mx-auto text-lg md:text-xl text-neutral-300 mb-10 font-light">
              Momos, Fried Rice & Finger Snacks <span className="font-semibold text-white">Starting at ₹20</span>.
              Experience luxury fast food crafted with passion.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a 
                href="https://wa.me/917571827445" 
                target="_blank" rel="noreferrer"
                className="w-full sm:w-auto px-8 py-4 bg-orange-600 hover:bg-orange-500 rounded-full font-medium text-white glow-btn transition-colors"
              >
                Order Now
              </a>
              <a 
                href="#menu" 
                className="w-full sm:w-auto px-8 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full font-medium text-white backdrop-blur-sm transition-colors"
              >
                View Menu
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Special Offer Banner */}
      <section className="py-8 relative z-20 -mt-12 mb-12 max-w-5xl mx-auto px-6">
        <motion.div 
          {...fadeInUp}
          className="glass rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 border-orange-500/30 bg-gradient-to-r from-orange-950/40 to-red-950/40 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4"></div>
          <div className="relative z-10 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-orange-500/20 flex items-center justify-center text-orange-400 flex-shrink-0">
              <Star className="w-6 h-6 fill-current" />
            </div>
            <div>
              <h3 className="font-serif text-2xl font-bold text-white mb-1">Special Offer</h3>
              <p className="text-orange-200 text-lg">Buy 2 Plates & Get Cold Drink <span className="font-bold text-white uppercase tracking-wider bg-orange-600 px-2 rounded-sm ml-1">Free</span></p>
            </div>
          </div>
          <a href="https://wa.me/917571827445" target="_blank" rel="noreferrer" className="relative z-10 whitespace-nowrap bg-white text-orange-900 px-6 py-3 rounded-full font-bold hover:bg-orange-100 transition-colors flex items-center gap-2">
            Claim Offer <ChevronRight className="w-4 h-4" />
          </a>
        </motion.div>
      </section>

      {/* Menu Section */}
      <section id="menu" className="py-24 relative">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div {...fadeInUp} className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">Our Signature Menu</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-orange-600 to-yellow-500 mx-auto rounded-full"></div>
            <p className="mt-6 text-neutral-400 max-w-2xl mx-auto text-lg">
              Indulge in our carefully curated selection of premium fast food, prepared fresh to order.
            </p>
          </motion.div>

          <motion.div 
            variants={staggerContainer}
            initial="initial"
            whileInView="whileInView"
            viewport={{ once: true, margin: "-100px" }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {menuItems.map((item, idx) => (
              <motion.div 
                key={idx}
                variants={{
                  initial: { opacity: 0, y: 20 },
                  whileInView: { opacity: 1, y: 0 }
                }}
                className="glass rounded-xl overflow-hidden group hover:border-orange-500/50 transition-colors duration-300 flex flex-col"
              >
                <div className="relative h-48 overflow-hidden">
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors z-10 duration-300"></div>
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute top-4 right-4 z-20 bg-black/70 backdrop-blur-sm text-yellow-400 font-bold px-3 py-1 rounded-full text-sm border border-yellow-500/30">
                    {item.price}
                  </div>
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="font-serif text-xl font-bold text-white mb-2">{item.name}</h3>
                  <p className="text-neutral-400 text-sm leading-relaxed mb-6 flex-1">
                    {item.desc}
                  </p>
                  <a href="https://wa.me/917571827445" target="_blank" rel="noreferrer" className="w-full py-2.5 px-4 rounded-lg bg-white/5 hover:bg-orange-600 border border-white/10 hover:border-orange-500 transition-all text-center text-sm font-medium text-white group-hover:glow-btn">
                    Order Now
                  </a>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* About Us Section */}
      <section id="about" className="py-24 bg-[#0a0a0a] relative overflow-hidden">
        <div className="absolute top-1/2 left-0 w-96 h-96 bg-orange-900/10 rounded-full blur-[100px] -translate-y-1/2"></div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div {...fadeInUp} className="relative">
              <div className="absolute -inset-4 bg-gradient-to-tr from-orange-600/20 to-transparent rounded-2xl blur-xl"></div>
              <img 
                src="https://images.unsplash.com/photo-1514933651103-005eec06c04b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                alt="Restaurant Interior"
                className="w-full h-full object-cover rounded-2xl relative z-10 border border-white/10 grayscale-[30%] hover:grayscale-0 transition-all duration-700"
              />
              <div className="absolute -bottom-8 -right-8 glass p-6 rounded-xl border border-white/10 hidden md:block z-20">
                <div className="flex items-center gap-4">
                  <div className="bg-orange-500/20 p-3 rounded-full text-orange-400">
                    <UtensilsCrossed className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-2xl font-serif font-bold text-white">Premium</h4>
                    <p className="text-neutral-400 text-sm uppercase tracking-wider">Quality</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div {...fadeInUp}>
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-6">A Taste of Luxury in <br/><span className="text-orange-500">Sangipur</span></h2>
              <p className="text-lg text-neutral-300 leading-relaxed mb-6 font-light">
                Raj Restaurant serves delicious and affordable fast food with premium quality, hygiene, and fast service in Sangipur. We believe that great taste doesn't have to come with a hefty price tag.
              </p>
              <p className="text-neutral-400 leading-relaxed mb-10">
                Our philosophy is simple: source fresh ingredients, prepare meals with authentic recipes, and serve them in an environment that feels luxurious and welcoming.
              </p>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="border-l-2 border-orange-500 pl-4">
                  <h4 className="text-white font-bold text-xl mb-1">Hygiene First</h4>
                  <p className="text-sm text-neutral-500">Impeccable cleanliness standards</p>
                </div>
                <div className="border-l-2 border-orange-500 pl-4">
                  <h4 className="text-white font-bold text-xl mb-1">Fast Service</h4>
                  <p className="text-sm text-neutral-500">Hot food delivered quickly</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div {...fadeInUp} className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div>
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">Visual Feast</h2>
              <div className="w-24 h-1 bg-gradient-to-r from-orange-600 to-yellow-500 rounded-full"></div>
            </div>
            <a href="https://instagram.com/brijesh_patel_544" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-orange-400 hover:text-orange-300 transition-colors group">
              <Instagram className="w-5 h-5" /> <span>@brijesh_patel_544</span>
            </a>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 auto-rows-[250px]">
            {galleryImages.map((src, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className={`relative rounded-xl overflow-hidden group ${i === 0 || i === 3 ? 'md:col-span-2' : ''}`}
              >
                <img 
                  src={src} 
                  alt={`Gallery ${i}`} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <Instagram className="text-white w-8 h-8 scale-0 group-hover:scale-100 transition-transform duration-500 delay-100" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-24 bg-[#0a0a0a] relative">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div {...fadeInUp} className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">Customer Love</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-orange-600 to-yellow-500 mx-auto rounded-full mb-6"></div>
            <p className="text-neutral-400 max-w-2xl mx-auto text-lg">Hear what our guests have to say about their royal experience.</p>
          </motion.div>

          <motion.div 
            variants={staggerContainer}
            initial="initial"
            whileInView="whileInView"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6"
          >
            {reviews.map((review, i) => (
              <motion.div 
                key={i}
                variants={{
                  initial: { opacity: 0, y: 30 },
                  whileInView: { opacity: 1, y: 0 }
                }}
                className="glass p-8 rounded-2xl border-t border-t-white/10 flex flex-col h-full hover:-translate-y-2 transition-transform duration-300"
              >
                <div className="flex text-yellow-500 mb-4">
                  {[...Array(review.rating)].map((_, j) => (
                    <Star key={j} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <p className="text-neutral-300 italic mb-8 flex-1 leading-relaxed text-lg">"{review.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-white font-bold font-serif text-xl shadow-lg">
                    {review.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-white font-bold">{review.name}</h4>
                    <p className="text-xs text-neutral-500">Verified Guest</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Contact & Map Section */}
      <section id="contact" className="py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-24">
            
            <motion.div {...fadeInUp}>
              <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">Visit Us</h2>
              <div className="w-24 h-1 bg-gradient-to-r from-orange-600 to-yellow-500 rounded-full mb-10"></div>
              
              <div className="space-y-8">
                <div className="flex items-start gap-4 p-4 rounded-xl hover:bg-white/5 transition-colors">
                  <div className="p-3 bg-orange-500/10 text-orange-500 rounded-lg">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-white mb-2">Location</h4>
                    <p className="text-neutral-400">Sangipur, Uttar Pradesh, India</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-xl hover:bg-white/5 transition-colors">
                  <div className="p-3 bg-orange-500/10 text-orange-500 rounded-lg">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-white mb-2">Phone</h4>
                    <p className="text-neutral-400">7571827445</p>
                    <a href="tel:7571827445" className="text-sm text-orange-400 hover:underline mt-1 inline-block">Call Now</a>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-xl hover:bg-white/5 transition-colors">
                  <div className="p-3 bg-orange-500/10 text-orange-500 rounded-lg">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-white mb-2">Opening Hours</h4>
                    <p className="text-neutral-400">Monday - Sunday</p>
                    <p className="text-neutral-500 text-sm">11:00 AM - 10:00 PM</p>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div {...fadeInUp} className="h-[400px] lg:h-auto min-h-[400px] rounded-2xl overflow-hidden glass border-white/10 p-2">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14349.566275825316!2d81.82110255!3d25.95514685!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399a9a3b2dc02787%3A0xc3fec3f422894569!2sSangipur%2C%20Uttar%20Pradesh%20230139!5e0!3m2!1sen!2sin!4v1709400000000!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style={{ border: 0, borderRadius: '0.75rem' }} 
                allowFullScreen={true} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Raj Restaurant Location"
                className="filter invert-[90%] hue-rotate-180 contrast-125 opacity-80 hover:opacity-100 transition-opacity duration-500 grayscale-[20%]"
              ></iframe>
            </motion.div>
            
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-16 border-t border-white/10 relative overflow-hidden">
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-orange-500/50 to-transparent"></div>
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-10 mb-12">
            <div className="md:col-span-1">
              <a href="#home" className="flex items-center gap-2 mb-6">
                <ChefHat className="text-orange-500 w-6 h-6" />
                <span className="font-serif text-xl font-bold text-white">Raj Restaurant</span>
              </a>
              <p className="text-neutral-500 text-sm mb-6 leading-relaxed">
                Premium fast food cafe serving the best Momos, Fried Rice, and snacks in Sangipur.
              </p>
              <div className="flex gap-4">
                <a href="https://instagram.com/brijesh_patel_544" target="_blank" rel="noreferrer" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-neutral-400 hover:text-white hover:bg-orange-600 transition-all">
                  <Instagram className="w-5 h-5" />
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6 tracking-wide">Quick Links</h4>
              <ul className="space-y-3">
                {navLinks.map(link => (
                  <li key={link.name}>
                    <a href={link.href} className="text-sm text-neutral-500 hover:text-orange-400 transition-colors">{link.name}</a>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6 tracking-wide">Legal</h4>
              <ul className="space-y-3">
                <li><a href="#" className="text-sm text-neutral-500 hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-sm text-neutral-500 hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="text-sm text-neutral-500 hover:text-white transition-colors">Refund Policy</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6 tracking-wide">Contact</h4>
              <ul className="space-y-3">
                <li className="text-sm text-neutral-500">Sangipur, UP, India</li>
                <li className="text-sm text-neutral-500">Phone: 7571827445</li>
                <li className="text-sm text-neutral-500">IG: @brijesh_patel_544</li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-white/10 text-center flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-neutral-600">
              © {new Date().getFullYear()} Raj Restaurant. All rights reserved.
            </p>
            <p className="text-sm text-neutral-600">
              Premium Taste. Affordable Price.
            </p>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <a 
        href="https://wa.me/917571827445" 
        target="_blank" 
        rel="noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:scale-110 hover:shadow-[0_0_20px_rgba(37,211,102,0.5)] transition-all duration-300 group flex items-center justify-center"
        aria-label="Order on WhatsApp"
      >
        <MessageCircle className="w-8 h-8" />
        <span className="absolute right-full mr-4 bg-white text-black px-3 py-1.5 rounded-lg text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-lg pointer-events-none">
          Order Now
        </span>
      </a>
      
    </div>
  );
}

